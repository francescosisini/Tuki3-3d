#include "giocatore.h"


azione turno_tuki(char oggetto_incontrato[DIM*DIM], stato st_tuki)
{
  /*Scrivi qui il tuo codice*/

  return MANGIA;
}
